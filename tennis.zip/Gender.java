package tennis;

public enum Gender {
    MAN,WOMAN;
}
