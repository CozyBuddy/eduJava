package tennis;

public class Set implements Tennis{

    @Override
    public void pointWinner() {

    }

    @Override
    public void dispScoreBoard() {

    }
}
