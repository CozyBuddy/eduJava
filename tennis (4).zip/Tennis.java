package tennis;

import java.util.ArrayList;

interface Tennis {
    public static ArrayList<Player> list = new ArrayList<>();
    public void pointWinner();
    public void dispScoreBoard();
}

