package days10;

/**
 * @author user
 * @date 2024. 1. 12. 오후 2:30:21
 * @subject
 * @contents
 */
public class Ex03 {
	public static void main(String[] args) {
		/*[배열] +제어문(for문)
		1. 자료형 
			1)기본형 	- 8가지
			2) 참조형 - 배열,클래스,인터페이스
		2. 배열 정의?
			1000명의 국어점수 저장. => 변수 선언.
		3..
	*/
	}

}
