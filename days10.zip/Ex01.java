package days10;

public class Ex01 {
	public static void main(String[] args) {
		// 달력 만들기
		// 만나이
		// 주민등록번호 - 검증,생년월일
		// 10 -> 0000 01010
	}

}
