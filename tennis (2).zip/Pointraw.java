package tennis;


import java.util.ArrayList;

public abstract class Pointraw {
	public static String name1 ;
	public static String name2 ;
	public static int count = 0;
	public static int count2 = 0;
	public static ArrayList<Integer> count3 = new ArrayList<>();
	public static int pointCount []  = new int[10];
	public static int point []  = new int[11];
	public static int games []  = new int[10];
	
	public static int sets []  = new int[10];
	public static ArrayList<Integer> alpoint  = new ArrayList(); //누적된 득점 포인트 , 번갈아가며 0인덱스에는 1팀의 누적득점포인트
	/*public static ArrayList<Integer> algames = new ArrayList();
	public static ArrayList<Integer> alsets  = new ArrayList();*/
	public static int point2 [] = new int[10];
	public static int sum1 =0 ;
	public static int sum2 =0;
	public static int count4 =0 ;
	public static int count5 =0 ;
	public static int count6 =0 ;
	public static int count7 =0;
	public static int count8 =0;
	public static int games2[] = new int[10];
	public static boolean bl = true;
	
	
}
