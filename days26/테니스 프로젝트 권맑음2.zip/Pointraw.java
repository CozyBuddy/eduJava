package days26;

import java.util.ArrayList;

public abstract class Pointraw {
	public static String name1 = "김진영";
	public static String name2 = "신슬기";
	public static int tempPoint1 [] = new int[10] ;
	public static int tempPoint2 [] = new int[10] ;
	public static boolean bl = false;
	public static int count = 0;
	public static int count2 = 0;
	public static ArrayList<Integer> count3 = new ArrayList<>();
	public static int pointCount []  = new int[10];
	public static int point []  = new int[11];
	public static int games []  = new int[10];
	
	public static int sets []  = new int[10];
	public static ArrayList<Integer> alpoint  = new ArrayList();
	/*public static ArrayList<Integer> algames = new ArrayList();
	public static ArrayList<Integer> alsets  = new ArrayList();*/
	
}
