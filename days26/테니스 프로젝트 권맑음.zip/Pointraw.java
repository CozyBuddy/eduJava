package days26;

import java.util.ArrayList;

public abstract class Pointraw {
	public static int count = 0;
	public static int count2 = 0;
	public static int point []  = new int[10];
	public static int games []  = new int[10];
	public static int sets []  = new int[10];
	public static ArrayList<Integer> alpoint  = new ArrayList();
	/*public static ArrayList<Integer> algames = new ArrayList();
	public static ArrayList<Integer> alsets  = new ArrayList();*/
	
}
