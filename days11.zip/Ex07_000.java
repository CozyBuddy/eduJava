package days11;

import java.util.stream.IntStream;

public class Ex07_000 {
	public static void main(String[] args) {
		int maxCount = IntStream.of(m).filter(i->i==max).count();
	}

}
