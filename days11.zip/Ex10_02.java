package days11;

import java.util.Arrays;

/**
 * @author user
 * @date 2024. 1. 15. 오후 3:43:35
 * @subject
 * @contents
 */
public class Ex10_02 {
	public static void main(String[] args) {
	
		int m[]= {3,5,2,4,1};
		System.out.println(Arrays.toString(m));
		
		Arrays.sort(m);
		System.out.println(Arrays.toString(m));
		
	}
}