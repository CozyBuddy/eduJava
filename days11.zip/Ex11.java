package days11;

/**
 * @author user
 * @date 2024. 1. 15. 오후 5:14:31
 * @subject
 * @contents
 */
public class Ex11 {
	public static void main(String[] args) {
		/*
		 * [다차원배열] 
		 * 1차원배열,2차원배열,3차원배열
		 * 배열의배열
		 *  편의를 위해서 다차원배열 사용.
		 */
			int m [] =new int[8];
			int m2 [][] = new int[4][2];
			int m3 [][][] = new int[2][2][2];
	}

}
