package tennis;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

public class DispWinner extends Pointraw  {
   //포인트와 팀명 혹은 이름을 받아서 스코어보드를 출력할 함수가 있는 클래스 , Pointraw 추상클래스를 상속받고 있음
   
   
   //현재의 스코어보드를 화면에 출력한다.
   public static void disppointBoard(String name , String name2, int c  ,int d) {  
      count2++; // 전체게임횟수를 카운트
      //pointCount[count]++; //
      point[count]+=c; //1번플레이어의 득점이면 그 세트의 포인트 점수 배열에 추가
      point[count+5]+=d; //2번플레이어의 득점이면 그 세트의 포인트 점수 배열에 추가
      alpoint.add(point[count]); // 파일 출력을 위한 arraylist 배열에 해당 게임시 생긴 포인트값을 저장
      alpoint.add(point[count+5]);
      
      
      if (point[count]>=40 && point[count+5]<=30&&(point[count]-point[count+5])>=10 ||point[count]>=40 &&point[count+5]>=40 && 
    		  (point[count]-point[count+5])>=20 ) {
         //1번플레이어가 이기는 경우 
         games[count]++; //1번플레이어의 이긴 게임 횟수 증가
         //출력부분
         System.out.println("┌"+"━".repeat(78)+"┐");
         System.out.println("┃ ╲       ┃"+" ".repeat(67)+" ┃");
         System.out.println("┃   ╲"+" 세트 ┃"+" ".repeat(10)+"I"+" ".repeat(10)+"II"+" ".repeat(10)+"III" +" ".repeat(10)+"IV"+" ".repeat(10)+"V"+" ".repeat(7)+"  ┃");
         System.out.println("┃      ╲  ┃"+" ".repeat(68)+"┃");
         System.out.println("┃   팀   ╲ ┃"+" ".repeat(67)+" ┃");
         System.out.println("━".repeat(80));
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃         ┃"+" ".repeat(10)+games[0]+" ".repeat(11)+games[1]+" ".repeat(11)+games[2]+" ".repeat(11)+games[3]+" ".repeat(11)+games[4]+"         ┃");
         System.out.println("┃  "+name+"   ┃"+" ".repeat(8)+"("+point[0]+")"+" ".repeat(9)+"("+point[1]+")"+" ".repeat(9)+"("+point[2]+")"+" ".repeat(9)+"("+point[3]+")"+" ".repeat(9)+"("+point[4]+")"+"        ┃");
         
         
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃"+"━".repeat(78)+"┃");
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃         ┃"+" ".repeat(10)+games[5]+" ".repeat(11)+games[6]+" ".repeat(11)+games[7]+" ".repeat(11)+games[8]+" ".repeat(11)+games[9]+"         ┃");

         System.out.println("┃  "+name2+"   ┃"+" ".repeat(8)+"("+point[5]+")"+" ".repeat(9)+"("+point[6]+")"+" ".repeat(9)+"("+point[7]+")"+" ".repeat(9)+"("+point[8]+")"+" ".repeat(9)+"("+point[9]+")"+"        ┃");
         
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("└"+"━".repeat(78)+"┘");
         point[count]=0; // 해당 세트의 포인트 점수값 초기화
         point[count+5]=0; 
         System.out.println("이 게임 승자는" + name +"팀");
         //gamesCount[count]++;
         count3.add(count2); // 파일 출력할때 각 득점별로 구분 짓기 위한 Arraylist배열
         
         count2=0;
          // 6게임을 선취득 했을 때 세트 승자로 선언
         if (games[count]==6) {
            System.out.println("이 세트 승자는" + name + "팀");
            sets[count]++;
            count++;
            
            
            
         }
      } else if (point[count+5]>=40 && point[count]<=30&& (point[count+5]-point[count])>=10 ||point[count+5]>=40 && point[count]>=40 &&(point[count+5]-point[count])>=20) {
         
         games[count+5]++;
         System.out.println("┌"+"━".repeat(78)+"┐");
         System.out.println("┃ ╲       ┃"+" ".repeat(67)+" ┃");
         System.out.println("┃   ╲"+" 세트 ┃"+" ".repeat(10)+"I"+" ".repeat(10)+"II"+" ".repeat(10)+"III" +" ".repeat(10)+"IV"+" ".repeat(10)+"V"+" ".repeat(7)+"  ┃");
         System.out.println("┃      ╲  ┃"+" ".repeat(68)+"┃");
         System.out.println("┃   팀   ╲ ┃"+" ".repeat(67)+" ┃");
         System.out.println("━".repeat(80));
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃         ┃"+" ".repeat(10)+games[0]+" ".repeat(11)+games[1]+" ".repeat(11)+games[2]+" ".repeat(11)+games[3]+" ".repeat(11)+games[4]+"         ┃");
         System.out.println("┃  "+name+"   ┃"+" ".repeat(8)+"("+point[0]+")"+" ".repeat(9)+"("+point[1]+")"+" ".repeat(9)+"("+point[2]+")"+" ".repeat(9)+"("+point[3]+")"+" ".repeat(9)+"("+point[4]+")"+"        ┃");
         
         
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃"+"━".repeat(78)+"┃");
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃         ┃"+" ".repeat(10)+games[5]+" ".repeat(11)+games[6]+" ".repeat(11)+games[7]+" ".repeat(11)+games[8]+" ".repeat(11)+games[9]+"         ┃");

         System.out.println("┃  "+name2+"   ┃"+" ".repeat(8)+"("+point[5]+")"+" ".repeat(9)+"("+point[6]+")"+" ".repeat(9)+"("+point[7]+")"+" ".repeat(9)+"("+point[8]+")"+" ".repeat(9)+"("+point[9]+")"+"        ┃");
         
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("└"+"━".repeat(78)+"┘");
         point[count]=0;
         point[count+5]=0;
         
         
         //gamesCount[count+5]++;
         count3.add(count2);
         count2=0;
         System.out.println("이 게임 승자는" + name2 +"팀");
         if (games[count+5]==6) {
            System.out.println("이 세트 승자는" + name2 + "팀");
            sets[count+5]++;
            count++;
            
            
         }
      } else {
         System.out.println("┌"+"━".repeat(78)+"┐");
         System.out.println("┃ ╲       ┃"+" ".repeat(67)+" ┃");
         System.out.println("┃   ╲"+" 세트 ┃"+" ".repeat(10)+"I"+" ".repeat(10)+"II"+" ".repeat(10)+"III" +" ".repeat(10)+"IV"+" ".repeat(10)+"V"+" ".repeat(7)+"  ┃");
         System.out.println("┃      ╲  ┃"+" ".repeat(68)+"┃");
         System.out.println("┃   팀   ╲ ┃"+" ".repeat(67)+" ┃");
         System.out.println("━".repeat(80));
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃         ┃"+" ".repeat(10)+games[0]+" ".repeat(11)+games[1]+" ".repeat(11)+games[2]+" ".repeat(11)+games[3]+" ".repeat(11)+games[4]+"         ┃");
         System.out.println("┃  "+name+"   ┃"+" ".repeat(8)+"("+point[0]+")"+" ".repeat(9)+"("+point[1]+")"+" ".repeat(9)+"("+point[2]+")"+" ".repeat(9)+"("+point[3]+")"+" ".repeat(9)+"("+point[4]+")"+"        ┃");
         
         
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃"+"━".repeat(78)+"┃");
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("┃         ┃"+" ".repeat(10)+games[5]+" ".repeat(11)+games[6]+" ".repeat(11)+games[7]+" ".repeat(11)+games[8]+" ".repeat(11)+games[9]+"         ┃");

         System.out.println("┃  "+name2+"   ┃"+" ".repeat(8)+"("+point[5]+")"+" ".repeat(9)+"("+point[6]+")"+" ".repeat(9)+"("+point[7]+")"+" ".repeat(9)+"("+point[8]+")"+" ".repeat(9)+"("+point[9]+")"+"        ┃");
         
         System.out.println("┃         ┃"+" ".repeat(68)+"┃");
         System.out.println("└"+"━".repeat(78)+"┘");
         
      }
      
      
      
    

      

   }
   
}
